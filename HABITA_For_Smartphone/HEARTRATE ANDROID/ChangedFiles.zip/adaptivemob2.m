close all;
clear all;
%filename_scg = 'etc/Acc_Wed Mar 11 140802 GMT+0000 2015.txt';
%filename_gcg ='etc/Gyro_Wed Mar 11 140802 GMT+0000 2015.txt';
%filename_scg = 'etc/Acc_Wed Mar 11 141755 GMT+0000 2015.txt';
%filename_gcg ='etc/Gyro_Wed Mar 11 141755 GMT+0000 2015.txt';
%filename_scg = 'etc/Acc_Thu Mar 12 172627 GMT+0000 2015.txt';
%filename_gcg ='etc/Gyro_Thu Mar 12 172627 GMT+0000 2015.txt';
%filename_scg = 'etc/Acc_Thu Mar 12 173636 GMT+0000 2015.txt';
%filename_gcg ='etc/Gyro_Thu Mar 12 173636 GMT+0000 2015.txt';
filename_scg = 'etc/Acc_Mon Mar 16 104138 GMT+0000 2015.txt';
filename_gcg ='etc/Gyro_Mon Mar 16 104138 GMT+0000 2015.txt';


delimiterIn = ' ';
headerlinesIn = 2;
A = importdata(filename_scg,delimiterIn,headerlinesIn);
B=importdata(filename_gcg,delimiterIn,headerlinesIn);

accX=A.data(:,1);
accY=A.data(:,2);
accZ=A.data(:,3);
GyrX=B.data(:,1);
GyrY=B.data(:,2);
GyrZ=B.data(:,3);
if length(accX)<length(GyrY)
    len=length(accX);
else
    len=length(GyrY);
end
accX=accX(1:len);
accY=accY(1:len);
accZ=accZ(1:len);
GyrX=GyrX(1:len);
GyrY=GyrY(1:len);
GyrZ=GyrZ(1:len);
%Signals=[accX,accY,accZ,GyrX,GyrY,GyrZ];
Signals=struct('accX',accX,'accY',accY,'accZ',accZ,'gyroX',GyrX,'gyroY',GyrY,'gyroZ',GyrZ);
Fs=200

coef=[1 1];

[AO_amp_gyr,AO_i_gyr,heartrate_gyr,t]=APD2(Signals,Fs,coef,2,1);

[AO_amp_acc,AO_i_acc,heartrate_acc,t]=APD2(Signals,Fs,coef,1,1);

[p_g_a,s_g_a,f_g_a] = Numeval( AO_i_gyr, AO_i_acc);

[p_a_g,s_a_g,f_a_g] = Numeval( AO_i_acc, AO_i_gyr);

if f_a_g<0.90 && f_g_a <0.90
    
    coef=[1 0];
    
    [AO1_amp_gyr,AO_1_gyr,heartrate_gyr1,t]=APD2(Signals,Fs,coef,2,0);
    
    [AO1_amp_acc,AO_1_acc,heartrate_acc1,t]=APD2(Signals,Fs,coef,1,0);
    
    [p1_g_a,s_g_a,f1_g_a] = Numeval( AO_1_gyr, AO_1_acc);
    
    [p1_a_g,s_a_g,f1_a_g] = Numeval( AO_1_acc, AO_1_gyr);
    
    AO_amp_gyr=AO1_amp_gyr;
    
    AO_i_gyr=AO_1_gyr;
    
    heartrate_gyr=heartrate_gyr1;
    
    AO_amp_acc=AO1_amp_acc;
    
    AO_i_acc=AO_1_acc;
    
    heartrate_acc=heartrate_acc1;
    
    if f1_g_a<0.90 && f1_a_g <0.90
        
        coef=[0 1];
        
        [AO2_amp_gyr,AO_2_gyr,heartrate_gyr2,t]=APD2(Signals,Fs,coef,2,0);
        
        [AO2_amp_acc,AO_2_acc,heartrate_acc2,t]=APD2(Signals,Fs,coef,1,0);
        
        [p2_g_a,s_g_a,f2_g_a] = Numeval( AO_2_gyr, AO_2_acc);
        
        [p2_a_g,s_a_g,f2_a_g] = Numeval( AO_2_acc, AO_2_gyr);
        
        AO_amp_gyr=AO2_amp_gyr;
        
        AO_i_gyr=AO_2_gyr;
        
        heartrate_gyr=heartrate_gyr2;
        
        AO_amp_acc=AO2_amp_acc;
        
        AO_i_acc=AO_2_acc;
        
        heartrate_acc=heartrate_acc2;
        
    else
        
        [AO_amp_gyr,AO_i_gyr,heartrate_gyr]=APD2(Signals,Fs,coef,2,1);
        
        [AO_amp_acc,AO_i_acc,heartrate_acc]=APD2(Signals,Fs,coef,1,1);
        
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_HR = table(heartrate_acc,heartrate_gyr,...
    'VariableNames',{'SCG_HR','GCG_HR'})


